# Download the Code.zip to Downloads Folder & Extract
## Instructions:
 - Open Terminal and Run the following commands
 ```
 cd Code/PythonScripts
 exit
 ```
  - To Run the Controllability script
 ```
 cd Code/PythonScripts
 python controllability.py
 exit
 ```

   - To Linearize the system using Jacobian
 ```
 cd Code/PythonScripts
 python Lyapunov_Jacobian_Linearization.py
 exit
 ```

    - To check closed loop LQR stability
 ```
 cd Code/PythonScripts
 python LyapunovIndirectMethod_LQRStability.py
 exit
 ```
 - To check observability
 ```
- Open Code/MatlabScripts directory in MATLAB
 RUN below files 
      -linear_system.m
      -lqr_controller.m
      -luenberger_observer.m
      -observability.m (Check its out put to replicate observability condition) 
      -linear_system.m
      -kalman_filter.m
 exit
 ```
- To Run Simulations
 ```
Follow the above step and run one of the simulations models in the Code/MatlabScripts directory to replicate the simulations in simulink
 exit
