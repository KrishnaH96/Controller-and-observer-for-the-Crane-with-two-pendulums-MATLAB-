from sympy import symbols, Matrix, simplify, shape, pprint

M, m1, m2, l1, l2, g, F = symbols(["M", "m1", "m2", "l1", "l2", "g", "F"])

print("This program verifies the controllability of the Linearized Crane system:")

A = Matrix([ 
      [0, 1, 0, 0, 0, 0],
      [0, 0, -1*g*m1/M, 0, -1*g*m2/M, 0],
      [0, 0, 0, 1, 0, 0],
      [0, 0, -g*(M+m1)/(M*l1), 0, -g*m2/(M*l1), 0],
      [0, 0, 0, 0, 0, 1],
      [0, 0, -1*g*m1/(M*l2), 0, -1*g*(M+m2)/(M*l2), 0]
    ])

B = Matrix([0, 1/M, 0, 1/(M*l1), 0, 1/(M*l2)])

pprint("A : ")
pprint(A)
pprint("B : ")
pprint(B)

# ctrb = simplify(Matrix([[B], [A@B], 
#     [A@A@B], [A@A@A@B], [A@A@A@A@B], [A@A@A@A@A@B]]))

pprint("Controllability Matrix of above LTI system is") 
pprint("[ B A*B A^2*B A^3*B A^4*B A^5*B ]") 

AB = A@B
A2B = A@A@B
A3B = A@A@A@B
A4B = A@A@A@A@B
A5B = A@A@A@A@A@B
ctrb = simplify(Matrix([
  [B[0], B[1], B[2], B[3], B[4], B[5]],
  [AB[0], AB[1], AB[2], AB[3], AB[4], AB[5]],
  [A2B[0], A2B[1], A2B[2], A2B[3], A2B[4], A2B[5]],
  [A3B[0], A3B[1], A3B[2], A3B[3], A3B[4], A3B[5]],
  [A4B[0], A4B[1], A4B[2], A4B[3], A4B[4], A4B[5]],
  [A5B[0], A5B[1], A5B[2], A5B[3], A5B[4], A5B[5]],
]))


pprint("We compute the full rank of the matrix by equating its determinant to zero.")
pprint("Determinant of above controllability matrix is computed as : ")
pprint(simplify(ctrb.det()))