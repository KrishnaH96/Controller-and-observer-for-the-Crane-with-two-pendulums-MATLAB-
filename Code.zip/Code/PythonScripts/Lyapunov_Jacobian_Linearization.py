from sympy import symbols, Matrix, simplify, shape, pprint, sin, cos, diff

M, m1, m2, l1, l2, g, F = symbols(["M", "m1", "m2", "l1", "l2", "g", "F"])

x, x_dot, x_dot_dot    = symbols(["x", "x_dot", "x_dot_dot"])
t1, t1_dot, t1_dot_dot = symbols(["t1", "t1_dot", "t1_dot_dot"])
t2, t2_dot, t2_dot_dot = symbols(["t2", "t2_dot", "t2_dot_dot"])

s1 = sin(t1)
c1 = cos(t1)

s2 = sin(t2)
c2 = cos(t2)


#Systems Non linear equations are given as
f1 = x_dot

f2 = (F - m1*(g*s1*c1 + l1*s1*t1_dot*t1_dot) - m2*(g*s2*c2 + l2*s2*t2_dot*t2_dot))/(M + m1*s1*s1+m2*s2*s2)

f3 = t1_dot

f4 = ((c1*f2) - (g*s1))/l1

f5 = t2_dot

f6 = ((c2*f2) - (g*s2))/l2

#Using Jacobian linearization Compute the system matrices as fllows
A = Matrix([
    [diff(f1, x), diff(f1, x_dot), diff(f1,t1), diff(f1,t1_dot), diff(f1,t2), diff(f1,t2_dot)],
    [diff(f2, x), diff(f2, x_dot), diff(f2,t1), diff(f2,t1_dot), diff(f2,t2), diff(f2,t2_dot)],
    [diff(f3, x), diff(f3, x_dot), diff(f3,t1), diff(f3,t1_dot), diff(f3,t2), diff(f3,t2_dot)],
    [diff(f4, x), diff(f4, x_dot), diff(f4,t1), diff(f4,t1_dot), diff(f4,t2), diff(f4,t2_dot)],
    [diff(f5, x), diff(f5, x_dot), diff(f5,t1), diff(f5,t1_dot), diff(f5,t2), diff(f5,t2_dot)],
    [diff(f6, x), diff(f6, x_dot), diff(f6,t1), diff(f6,t1_dot), diff(f6,t2), diff(f6,t2_dot)],
    ])

B = Matrix([
     [diff(f1, F)],
     [diff(f2, F)],
     [diff(f3, F)],
     [diff(f4, F)],
     [diff(f5, F)],
     [diff(f6, F)],
])

#Lyapunov Indirect Method or Jacobian Linearization around equilibrium point
A_linear = A.subs({t1:0, t2:0, t1_dot:0, t2:0, t2_dot:0})
B_linear = B.subs({t1:0, t2:0, t1_dot:0, t2:0, t2_dot:0})

pprint("A Linear : ")
pprint(A_linear)
pprint("B Lieanr : ")
pprint(B_linear)


