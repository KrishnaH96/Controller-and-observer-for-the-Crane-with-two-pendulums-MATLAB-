
%In this system we use the lqr controller for feed back and 
% solve for the observer gain using Kalman Bucy estimator

% the system output is considered to 
% be the minimum observable state i.e, x(t)

%System and measurement noise covarience are defined as below
Vd = 0.1*eye(6);
Vn = 1;

% x_dot = Ax + Bu + Vd*d +  0*n
% y     = Cx + Du +  0*d + Vn*n

% Augemented B
BF = [B Vd 0*B]

% Augmented D : [0-for-B [0 0 0 0 0 0]-for-Vd Vn]
D  = [0 0 0 0 0 0 0 Vn]

sysC = ss(A, BF, C1, D)


disp('LQR parameters:')
lqg_Q = 0.01*eye(6)


lqg_R = 100

disp('LQR gains are found as:')
lqg_K = lqr(A,B,lqg_Q,lqg_R)

sysFullOutput = ss(A, BF, eye(6), zeros(6, size(BF, 2)))

%% Build Kalman filter
% [Kf,P,E] = lqe(A, Vd, C, Vd, Vn)

Kf    = (lqr(A', C1', Vd, Vn))'

sysKF = ss(A-Kf*C1, [B Kf], eye(6), 0*[B Kf])


%% Simulate original system
 dt = 0.01;
 t = dt:dt:200
 
 uDIST  = randn(6, size(t, 2));
 uNOISE = randn(size(t));
 u = 0*t
 u(10:20)   = 100
 
 uDIST_mod = Vd*Vd*uDIST;
 
 uAUG = [u; uDIST_mod; uNOISE];

% dt = 0.01;
% t = dt:dt:200
% 
% uDIST  = randn(6, size(t, 2));
% uNOISE = randn(size(t));
% u = 0*t
% u(200:600)   = 100
% u(1500:2000)   = -100
% 
% uDIST_mod = Vd*Vd*uDIST;
% 
% uAUG = [u; uDIST_mod; uNOISE];

[y, t] = lsim(sysC, uAUG, t);
plot(t, y);

%% Simulate full system
[xtrue, t] = lsim(sysFullOutput, uAUG, t);

hold on

plot(t,xtrue(:,1),'r','LineWidth',1.0)

%% Kalman Filter Estimate
[x,t] = lsim(sysKF, [u; y'], t);
plot(t, x(:,1), 'k--', 'linewidth', 1.0)

plot(t, xtrue, '-', t, x, '--', 'LineWidth', 2)
