disp('Given Parameters of the System\n')

fprintf('M : %i, m1:%i, m2:%i, l1:%i, l2:%i', 1000, 100, 100, 20, 10)

A = double(subs(A, [M m1 m2, l1, l2, g],[1000 100 100, 20, 10, 9.8]))
B = double(subs(B, [M m1 m2, l1, l2, g],[1000 100 100, 20, 10, 9.8]))

fprintf(['Eigen values of A :\n'])
eigs(A)

disp('We have seen that the sytem is observable for states [x(t)]; [x(t), θ2(t)]; [x(t), θ1(t), θ2(t)]')
disp(newline)
disp(['Luenberger observer gain for each of these states can be solved ' ...
    'using LQR controller for the system [At-Ct*Lt]'])
disp(newline)
disp('--------------------------------')
disp('Case 1 : Luenberger observer gain for state = [x(t)] ')
disp('--------------------------------')



disp('LQR parameters:')

Q = 100 * eye(6);%rate of performance

R = 0.1;%energy efficiency

disp('LQR gains are found as:')
Lt = lqr(transpose(A),transpose(C1),Q,R);
L1 = transpose(Lt)

disp(newline)
disp('--------------------------------')
disp('Case 3 : state = [x(t), θ2(t)] ')
disp('--------------------------------')



disp('LQR parameters:')


disp('LQR gains are found as:')
Lt = lqr(transpose(A),transpose(C3),Q,R);
L3 = transpose(Lt)



disp(newline)
disp('--------------------------------')
disp('Case 4 : state = [x(t), θ1(t), θ2(t)] ')
disp('--------------------------------')


disp('LQR parameters:')


disp('LQR gains are found as:')
Lt = lqr(transpose(A),transpose(C4),Q,R);
L4 = transpose(Lt)

