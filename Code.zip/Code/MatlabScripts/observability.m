disp('Given Parameters of the System\n')

fprintf('M : %i, m1:%i, m2:%i, l1:%i, l2:%i', 1000, 100, 100, 20, 10)

A = double(subs(A, [M m1 m2, l1, l2, g],[1000 100 100, 20, 10, 9.8]));
B = double(subs(B, [M m1 m2, l1, l2, g],[1000 100 100, 20, 10, 9.8]));


disp(newline)
disp('--------------------------------')
disp('Case 1 : state = [x(t)] ')
disp('--------------------------------')

% C1 = [1 0 0 0 0 0;
%       0 0 0 0 0 0;
%       0 0 0 0 0 0;
%       0 0 0 0 0 0;
%       0 0 0 0 0 0;
%       0 0 0 0 0 0];
C1 = [1 0 0 0 0 0];
D1 = 0;

Ct = transpose(C1);
At = transpose(A);

A1C = At*Ct;
A2C = At*At*Ct;
A3C = At*At*At*Ct;
A4C = At*At*At*At*Ct;
A5C = At*At*At*At*At*Ct;

O = [Ct A1C A2C A3C A4C A5C];

R = rank(O);

fprintf('Rank of Observability Matrix : %f', R)
disp(newline)

if R == 6
    disp("State is observable")
else
    disp("State is not observable")
end

disp(newline)




disp(newline)
disp('--------------------------------')
disp('Case 2 : state = [θ1(t), θ2(t)] ')
disp('--------------------------------')

C2 = [0 0 1 0 0 0; 0 0 0 0 1 0];
D2 = [0;0];

Ct = transpose(C2);
At = transpose(A);

A1C = At*Ct;
A2C = At*At*Ct;
A3C = At*At*At*Ct;
A4C = At*At*At*At*Ct;
A5C = At*At*At*At*At*Ct;

O = [Ct A1C A2C A3C A4C A5C];

R = rank(O);

fprintf('Rank of Observability Matrix : %f', R)
disp(newline)

if R == 6
    disp("State is observable")
else
    disp("State is not observable")
end

disp(newline)



disp(newline)
disp('--------------------------------')
disp('Case 3 : state = [x(t), θ2(t)] ')
disp('--------------------------------')

C3 = [1 0 0 0 0 0; 0 0 0 0 1 0];
D3 = [0;0];

Ct = transpose(C3);
At = transpose(A);

A1C = At*Ct;
A2C = At*At*Ct;
A3C = At*At*At*Ct;
A4C = At*At*At*At*Ct;
A5C = At*At*At*At*At*Ct;

O = [Ct A1C A2C A3C A4C A5C];

R = rank(O);

fprintf('Rank of Observability Matrix : %f', R)
disp(newline)

if R == 6
    disp("State is observable")
else
    disp("State is not observable")
end

disp(newline)


disp(newline)
disp('--------------------------------')
disp('Case 4 : state = [x(t), θ1(t), θ2(t)] ')
disp('--------------------------------')

C4 = [1 0 0 0 0 0; 0 0 1 0 0 0; 0 0 0 0 1 0];
D4 = [0;0;0];

Ct = transpose(C4);
At = transpose(A);

A1C = At*Ct;
A2C = At*At*Ct;
A3C = At*At*At*Ct;
A4C = At*At*At*At*Ct;
A5C = At*At*At*At*At*Ct;

O = [Ct A1C A2C A3C A4C A5C];

R = rank(O);

fprintf('Rank of Observability Matrix : %f', R)
disp(newline)

if R == 6
    disp("State is observable")
else
    disp("State is not observable")
end

disp(newline)

