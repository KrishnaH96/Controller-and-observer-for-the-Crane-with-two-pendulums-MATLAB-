disp('Given Parameters of the System\n')

fprintf('M : %i, m1:%i, m2:%i, l1:%i, l2:%i', 1000, 100, 100, 20, 10)

A = double(subs(A, [M m1 m2, l1, l2, g],[1000 100 100, 20, 10, 9.8]))
B = double(subs(B, [M m1 m2, l1, l2, g],[1000 100 100, 20, 10, 9.8]))

% fprintf(['Eigen values of A :\n'])
% eigs(A)


Sc = ctrb(A, B);

disp('--------------------------------------------------------------------------------')
disp('Check if system is controllable using rank condition\n')
disp('--------------------------------------------------------------------------------')
fprintf(['Rank of Controllability matrix ' ...
    'is : %i\n'], rank(ctrb(A, B)))

if rank(ctrb(A, B)) == 6
    disp('System is Controllable.\n')
else 
    disp('System is Uncontrollable.\n')
end

disp(newline)
disp('--------------------------------------------------------------------------------')
disp('Find gain matrix using LQR method\n')
disp('--------------------------------------------------------------------------------')



disp('LQR parameters:')


 Q = [1 0 0 0 0 0;
      0 1 0 0 0 0;
      0 0 10 0 0 0;
      0 0 0 10 0 0;
      0 0 0 0 10 0;
      0 0 0 0 0 10]
 
 
 R = 0.001

disp('LQR gains are found as:')
K = lqr(A,B,Q,R)

disp('Eigen Values of Closed loop system after  applying LQR.\n')
eigs(A-(B*K))

disp(newline)
disp('--------------------------------------------------------------------------------')
disp('Checking for stabiity of LQR Closed Loop system using Lyapnov indirect method.')
disp('--------------------------------------------------------------------------------')
disp('Lyapnov Solution of Closed loop system after  applying LQR.\n')
P = lyap(A-(B*K), Q)


if issymmetric(P) && all(eigs(P) > 0)
    disp('Lyapnov Solution is Positive definite and hence system is stable')
else
    disp('Lyapnov Solution is not Positive definite and hence system is unstable')
end
C = [1 0 0 0 0 0; 0 1 0 0 0 0; 0 0 1 0 0 0; 0 0 0 1 0 0; 0 0 0 0 1 0; 0 0 0 0 0 1];
D = [0;0;0;0;0;0];
Init_S1 = [1; 0; deg2rad(1); 0; 0; deg2rad(0.5)];
Init_S2 = [0.5; 0.01; deg2rad(5); deg2rad(0.01); deg2rad(2); deg2rad(0.01)];